// Top-level build file
plugins {
    id("com.android.application") version "8.3.0" apply false
    kotlin("android") version "1.9.23" apply false
}